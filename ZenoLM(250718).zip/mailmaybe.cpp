#include "stdafx.h"
#include <strsafe.h>
#include "resource.h"
#include "colours.h"
#include "easendmailobj.tlh"
#include <tchar.h>


using namespace EASendMailObjLib;


//In order to run it correctly, gotta change SMTP server, user, password, sender, recipient value to proper ones.
//actually, gotta change and fix pretty much everything in orange

bool sendmail = m_bDoSomething;//GOTTA FIX THE HIERARCY HERE

//AT THE MOMENT CHECKING THE CODE IN SEPARATE PROJECT "LETSTRYAGAIN", STILL NOT WORKING 

int _tmain(int argc, _TCHAR* argv[])
{
	if (sendmail)   
	{
		::CoInitialize(NULL);

		IMailPtr oSmtp = NULL;
		oSmtp.CreateInstance("EASendMailObj.Mail");
		oSmtp->LicenseCode = _T("TryIt");

		// Set your sender email address
		oSmtp->FromAddr = _T("test@emailarchitect.net");

		// Add recipient email address
		oSmtp->AddRecipientEx(_T("support@emailarchitect.net"), 0);

		// Set email subject
		oSmtp->Subject = _T("HTML email from Visual C++ project with attachment");

		// Set HTML body format
		oSmtp->BodyFormat = 1;

		// Set HTML body text
		oSmtp->BodyText = _T("<font size=5>This is</font> <font color=red><b>a test</b></font>");

		// Add attachment from local disk
		if (oSmtp->AddAttachment(_T("C:/Users/STV2/Pictures/filename.bmp")) != 0)
		{
			_tprintf(_T("Failed to add attachment with error: %s\r\n"),
				(const TCHAR*)oSmtp->GetLastErrDescription());
		}
		/*
		// Add attachment from remote website
		if (oSmtp->AddAttachment("http://www.emailarchitect.net/webapp/img/logo.jpg") != 0)
		{
			_tprintf(_T("Failed to add attachment with error: %s\r\n"),
				(const TCHAR*)oSmtp->GetLastErrDescription());
		}
		*/
		// Your SMTP server address
		oSmtp->ServerAddr = _T("smtp.emailarchitect.net"); //<----here

		// User and password for ESMTP authentication, if server doesn't
		// require User authentication, remove the following codes.
		oSmtp->UserName = _T("test@emailarchitect.net");	//<---here
		oSmtp->Password = _T("testpassword");				//<-----here

		// If SMTP server requires SSL connection, add this line
		// oSmtp->SSL_init();

		_tprintf(_T("Start to send HTML email ...\r\n"));

		if (oSmtp->SendMail() == 0)
		{
			_tprintf(_T("email was sent successfully!\r\n"));
		}
		else
		{
			_tprintf(_T("failed to send email with the following error: %s\r\n"),
				(const TCHAR*)oSmtp->GetLastErrDescription());
		}

		if (oSmtp != NULL)
			oSmtp.Release();

		return 0;
	}
}